import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { X, Calendar, Calculator, MapPin } from 'lucide-react';
import { Car, City } from '../types';
import { useBooking } from '../hooks/useBooking';
import { TravelSidebar } from './TravelSidebar';

interface BookingModalProps {
  car: Car | null;
  city: City | null;
  isOpen: boolean;
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ 
  car, 
  city, 
  isOpen, 
  onClose 
}) => {
  const { t } = useTranslation();
  const { calculatePricing } = useBooking();
  const [days, setDays] = useState(3);
  const [daysError, setDaysError] = useState('');

  if (!isOpen || !car || !city) return null;

  const handleDaysChange = (value: number) => {
    if (value < car.minDays) {
      setDaysError(t('minimum_days_error'));
    } else {
      setDaysError('');
    }
    setDays(value);
  };

  const deliveryFee = 0; // Center city delivery is free
  const pricing = calculatePricing(car.dailyPrice, days, deliveryFee);

  const handleBooking = () => {
    if (days < car.minDays) {
      setDaysError(t('minimum_days_error'));
      return;
    }
    
    // Here you would typically send the booking data to your API
    console.log('Booking confirmed:', {
      car: car.id,
      city: city.id,
      days,
      pricing
    });
    
    alert('Booking confirmed! You will receive a confirmation SMS shortly.');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex">
          {/* Main booking content */}
          <div className="flex-1 p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Calendar className="text-orange-500" size={24} />
                <h2 className="text-2xl font-bold text-gray-900">
                  {t('rental_calculator')}
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <img
                  src={car.image}
                  alt={`${car.brand} ${car.model}`}
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {car.brand} {car.model}
                </h3>
                <div className="flex items-center gap-2 text-gray-600 mb-4">
                  <MapPin size={16} />
                  <span>{t(`cities.${city.id}`)}</span>
                </div>
                <div className="text-sm text-gray-600">
                  <p className="mb-1">{t('emergency_contact')}: {city.emergencyContact}</p>
                  <p>{t('tourism_license')}</p>
                </div>
              </div>

              <div>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('rental_duration')}
                  </label>
                  <input
                    type="number"
                    min={car.minDays}
                    value={days}
                    onChange={(e) => handleDaysChange(parseInt(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                  {daysError && (
                    <p className="text-red-500 text-sm mt-1">{daysError}</p>
                  )}
                  <p className="text-gray-500 text-sm mt-1">
                    {t('min_3_days')}
                  </p>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Calculator size={20} className="text-orange-500" />
                    <h4 className="font-semibold text-gray-900">
                      {t('pricing_breakdown')}
                    </h4>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>{t('base_price')} ({days} {t('days')})</span>
                      <span>{pricing.basePrice} MAD</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{t('delivery_fee')}</span>
                      <span>{pricing.deliveryFee} MAD</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{t('vat')}</span>
                      <span>{pricing.vatAmount.toFixed(2)} MAD</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-bold">
                      <span>{t('total')}</span>
                      <span>{pricing.finalTotal.toFixed(2)} MAD</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleBooking}
                  disabled={days < car.minDays}
                  className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg font-semibold hover:from-orange-600 hover:to-orange-700 transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  {t('book_now')}
                </button>
              </div>
            </div>
          </div>

          {/* Travel sidebar */}
          <TravelSidebar city={city} />
        </div>
      </div>
    </div>
  );
};