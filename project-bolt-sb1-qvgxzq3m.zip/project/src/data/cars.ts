import { Car } from '../types';

export const cars: Car[] = [
  {
    id: 'dacia-logan-1',
    model: 'Logan',
    brand: 'Dacia',
    image: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=800',
    cities: ['casablanca', 'rabat', 'marrakech'],
    dailyPrice: 280,
    seats: 5,
    transmission: 'manual',
    hasAC: true,
    deliveryZones: {
      center: { fee: 0, radius: 10 },
      mid: { fee: 99, radius: 20 },
      far: 'contact'
    },
    minDays: 3,
    features: ['GPS', 'Bluetooth', 'Insurance'],
    category: 'economy'
  },
  {
    id: 'renault-clio-1',
    model: 'Clio',
    brand: 'Renault',
    image: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=800',
    cities: ['casablanca', 'tanger', 'agadir'],
    dailyPrice: 320,
    seats: 5,
    transmission: 'automatic',
    hasAC: true,
    deliveryZones: {
      center: { fee: 0, radius: 10 },
      mid: { fee: 99, radius: 20 },
      far: 'contact'
    },
    minDays: 3,
    features: ['GPS', 'Bluetooth', 'Insurance', 'Cruise Control'],
    category: 'comfort'
  },
  {
    id: 'mercedes-a-class-1',
    model: 'A-Class',
    brand: 'Mercedes',
    image: 'https://images.pexels.com/photos/3802508/pexels-photo-3802508.jpeg?auto=compress&cs=tinysrgb&w=800',
    cities: ['casablanca', 'marrakech', 'rabat'],
    dailyPrice: 580,
    seats: 5,
    transmission: 'automatic',
    hasAC: true,
    deliveryZones: {
      center: { fee: 0, radius: 10 },
      mid: { fee: 99, radius: 20 },
      far: 'contact'
    },
    minDays: 3,
    features: ['GPS', 'Bluetooth', 'Insurance', 'Leather Seats', 'Sunroof'],
    category: 'luxury'
  },
  {
    id: 'toyota-prado-1',
    model: 'Prado',
    brand: 'Toyota',
    image: 'https://images.pexels.com/photos/1637859/pexels-photo-1637859.jpeg?auto=compress&cs=tinysrgb&w=800',
    cities: ['marrakech', 'agadir', 'tanger'],
    dailyPrice: 750,
    seats: 7,
    transmission: 'automatic',
    hasAC: true,
    deliveryZones: {
      center: { fee: 0, radius: 10 },
      mid: { fee: 99, radius: 20 },
      far: 'contact'
    },
    minDays: 3,
    features: ['GPS', 'Bluetooth', 'Insurance', '4WD', 'Roof Rails'],
    category: 'suv'
  },
  {
    id: 'bmw-3-series-1',
    model: '3 Series',
    brand: 'BMW',
    image: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=800',
    cities: ['casablanca', 'rabat'],
    dailyPrice: 680,
    seats: 5,
    transmission: 'automatic',
    hasAC: true,
    deliveryZones: {
      center: { fee: 0, radius: 10 },
      mid: { fee: 99, radius: 20 },
      far: 'contact'
    },
    minDays: 3,
    features: ['GPS', 'Bluetooth', 'Insurance', 'Sport Mode', 'Premium Sound'],
    category: 'luxury'
  },
  {
    id: 'hyundai-tucson-1',
    model: 'Tucson',
    brand: 'Hyundai',
    image: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=800',
    cities: ['marrakech', 'agadir', 'tanger', 'casablanca'],
    dailyPrice: 450,
    seats: 5,
    transmission: 'automatic',
    hasAC: true,
    deliveryZones: {
      center: { fee: 0, radius: 10 },
      mid: { fee: 99, radius: 20 },
      far: 'contact'
    },
    minDays: 3,
    features: ['GPS', 'Bluetooth', 'Insurance', 'Backup Camera'],
    category: 'suv'
  }
];