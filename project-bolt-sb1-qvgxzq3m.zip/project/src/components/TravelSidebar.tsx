import React from 'react';
import { useTranslation } from 'react-i18next';
import { Hotel, MapPin, Star, Clock } from 'lucide-react';
import { City } from '../types';
import { hotels } from '../data/hotels';
import { experiences } from '../data/experiences';

interface TravelSidebarProps {
  city: City;
}

export const TravelSidebar: React.FC<TravelSidebarProps> = ({ city }) => {
  const { t } = useTranslation();

  return (
    <div className="w-80 bg-gray-50 p-6 border-l">
      <h3 className="text-xl font-bold text-gray-900 mb-4">
        {t('complete_your_trip')}
      </h3>

      {/* Hotels Section */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <Hotel size={20} className="text-blue-500" />
          <h4 className="font-semibold text-gray-900">
            {t('recommended_hotels')}
          </h4>
        </div>
        <div className="space-y-3">
          {hotels.slice(0, 3).map((hotel) => (
            <div key={hotel.id} className="bg-white rounded-lg p-3 shadow-sm">
              <img
                src={hotel.image}
                alt={hotel.name}
                className="w-full h-20 object-cover rounded-md mb-2"
              />
              <h5 className="font-medium text-gray-900 text-sm mb-1">
                {hotel.name}
              </h5>
              <div className="flex items-center gap-1 mb-1">
                <MapPin size={12} className="text-gray-400" />
                <span className="text-xs text-gray-600">{hotel.location}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star size={12} className="text-yellow-400 fill-current" />
                  <span className="text-xs text-gray-600">{hotel.rating}</span>
                </div>
                <span className="text-sm font-semibold text-gray-900">
                  {hotel.pricePerNight} MAD {t('per_night')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Experiences Section */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <MapPin size={20} className="text-orange-500" />
          <h4 className="font-semibold text-gray-900">
            {t('experiences')}
          </h4>
        </div>
        <div className="space-y-3">
          {experiences.slice(0, 3).map((experience) => (
            <div key={experience.id} className="bg-white rounded-lg p-3 shadow-sm">
              <img
                src={experience.image}
                alt={experience.title}
                className="w-full h-20 object-cover rounded-md mb-2"
              />
              <h5 className="font-medium text-gray-900 text-sm mb-1">
                {experience.title}
              </h5>
              <div className="flex items-center gap-1 mb-1">
                <Clock size={12} className="text-gray-400" />
                <span className="text-xs text-gray-600">{experience.duration}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-600 capitalize">
                  {experience.category}
                </span>
                <span className="text-sm font-semibold text-gray-900">
                  {experience.price} MAD
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};