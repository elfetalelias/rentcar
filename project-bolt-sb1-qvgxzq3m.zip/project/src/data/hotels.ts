import { Hotel } from '../types';

export const hotels: Hotel[] = [
  {
    id: 'riad-marrakech-1',
    name: 'Riad Atlas Heritage',
    image: 'https://images.pexels.com/photos/1134176/pexels-photo-1134176.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    pricePerNight: 650,
    location: 'Marrakech Medina'
  },
  {
    id: 'hotel-casa-1',
    name: 'Hotel Kenzi Tower',
    image: 'https://images.pexels.com/photos/1134176/pexels-photo-1134176.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    pricePerNight: 890,
    location: 'Casablanca Centre'
  },
  {
    id: 'riad-rabat-1',
    name: 'Riad Dar El Kebira',
    image: 'https://images.pexels.com/photos/1134176/pexels-photo-1134176.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    pricePerNight: 720,
    location: 'Rabat Medina'
  }
];