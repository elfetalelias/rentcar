export interface Car {
  id: string;
  model: string;
  brand: string;
  image: string;
  cities: string[];
  dailyPrice: number;
  seats: number;
  transmission: 'automatic' | 'manual';
  hasAC: boolean;
  deliveryZones: {
    center: { fee: number; radius: number };
    mid: { fee: number; radius: number };
    far: string;
  };
  minDays: number;
  features: string[];
  category: 'economy' | 'comfort' | 'luxury' | 'suv';
}

export interface City {
  id: string;
  name: string;
  nameAr: string;
  emergencyContact: string;
  latitude: number;
  longitude: number;
}

export interface BookingDetails {
  carId: string;
  cityId: string;
  startDate: string;
  endDate: string;
  days: number;
  totalPrice: number;
  deliveryFee: number;
  vatAmount: number;
  finalTotal: number;
}

export interface Hotel {
  id: string;
  name: string;
  image: string;
  rating: number;
  pricePerNight: number;
  location: string;
}

export interface Experience {
  id: string;
  title: string;
  image: string;
  price: number;
  duration: string;
  category: string;
}