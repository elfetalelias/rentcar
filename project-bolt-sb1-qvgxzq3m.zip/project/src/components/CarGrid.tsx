import React from 'react';
import { useTranslation } from 'react-i18next';
import { Car } from '../types';
import { CarCard } from './CarCard';

interface CarGridProps {
  cars: Car[];
  onBookClick: (carId: string) => void;
}

export const CarGrid: React.FC<CarGridProps> = ({ cars, onBookClick }) => {
  const { t } = useTranslation();

  if (cars.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">
          {t('no_cars_available')}
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {cars.map((car) => (
        <CarCard
          key={car.id}
          car={car}
          onBookClick={onBookClick}
        />
      ))}
    </div>
  );
};