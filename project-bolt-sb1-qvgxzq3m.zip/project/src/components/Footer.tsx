import React from 'react';
import { useTranslation } from 'react-i18next';
import { Car, Phone, Mail, MapPin } from 'lucide-react';

export const Footer: React.FC = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Car size={32} className="text-orange-500" />
              <div>
                <h3 className="text-xl font-bold">MoroDrive</h3>
                <p className="text-gray-400">Premium Car Rental</p>
              </div>
            </div>
            <p className="text-gray-400 mb-4">
              {t('footer_text')}
            </p>
            <p className="text-sm text-gray-500">
              {t('tourism_license')}
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <div className="space-y-2 text-gray-400">
              <div className="flex items-center gap-2">
                <Phone size={16} />
                <span>+212 800 123 456</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={16} />
                <span>contact@morodrive.ma</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={16} />
                <span>Casablanca, Morocco</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">{t('emergency_contact')}</h4>
            <div className="space-y-2 text-gray-400 text-sm">
              <p>Casablanca: +212 522 123 456</p>
              <p>Marrakech: +212 524 123 456</p>
              <p>Rabat: +212 537 123 456</p>
              <p>Tangier: +212 539 123 456</p>
              <p>Agadir: +212 528 123 456</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 MoroDrive. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};