import React from 'react';
import { useTranslation } from 'react-i18next';
import { MapPin } from 'lucide-react';
import { cities } from '../data/cities';

interface CitySelectorProps {
  selectedCity: string;
  onCityChange: (city: string) => void;
}

export const CitySelector: React.FC<CitySelectorProps> = ({ selectedCity, onCityChange }) => {
  const { t } = useTranslation();

  return (
    <div className="relative">
      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
        <MapPin className="h-5 w-5 text-gray-400" />
      </div>
      <select
        id="citySelector"
        value={selectedCity}
        onChange={(e) => onCityChange(e.target.value)}
        className="block w-full pl-10 pr-3 py-4 text-lg border-2 border-white/20 rounded-lg bg-white/90 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-colors"
      >
        <option value="">{t('select_city')}</option>
        {cities.map((city) => (
          <option key={city.id} value={city.id}>
            {t(`cities.${city.id}`)}
          </option>
        ))}
      </select>
    </div>
  );
};