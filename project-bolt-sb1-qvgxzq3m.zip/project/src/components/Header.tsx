import React from 'react';
import { useTranslation } from 'react-i18next';
import { Car, Phone } from 'lucide-react';
import { LanguageSwitcher } from './LanguageSwitcher';

export const Header: React.FC = () => {
  const { t } = useTranslation();

  return (
    <header className="bg-gradient-to-r from-orange-500 to-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Car size={32} className="text-white" />
            <div>
              <h1 className="text-2xl font-bold">MoroDrive</h1>
              <p className="text-sm opacity-90">Premium Car Rental</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2">
              <Phone size={20} />
              <span>+212 800 123 456</span>
            </div>
            <LanguageSwitcher />
          </div>
        </div>
      </div>
    </header>
  );
};