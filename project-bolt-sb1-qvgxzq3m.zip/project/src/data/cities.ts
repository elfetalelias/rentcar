import { City } from '../types';

export const cities: City[] = [
  {
    id: 'casablanca',
    name: 'Casablanca',
    nameAr: 'الدار البيضاء',
    emergencyContact: '+212 522 123 456',
    latitude: 33.5731,
    longitude: -7.5898
  },
  {
    id: 'marrakech',
    name: 'Marrakech',
    nameAr: 'مراكش',
    emergencyContact: '+212 524 123 456',
    latitude: 31.6295,
    longitude: -7.9811
  },
  {
    id: 'rabat',
    name: 'Rabat',
    nameAr: 'الرباط',
    emergencyContact: '+212 537 123 456',
    latitude: 34.0209,
    longitude: -6.8416
  },
  {
    id: 'tanger',
    name: 'Tangier',
    nameAr: 'طنجة',
    emergencyContact: '+212 539 123 456',
    latitude: 35.7595,
    longitude: -5.8340
  },
  {
    id: 'agadir',
    name: 'Agadir',
    nameAr: 'أكادير',
    emergencyContact: '+212 528 123 456',
    latitude: 30.4278,
    longitude: -9.5981
  }
];