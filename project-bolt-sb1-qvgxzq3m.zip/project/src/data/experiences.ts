import { Experience } from '../types';

export const experiences: Experience[] = [
  {
    id: 'desert-tour-1',
    title: 'Sahara Desert 3-Day Tour',
    image: 'https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 2500,
    duration: '3 days',
    category: 'Adventure'
  },
  {
    id: 'marrakech-guide-1',
    title: 'Marrakech Medina Walking Tour',
    image: 'https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 350,
    duration: '4 hours',
    category: 'Culture'
  },
  {
    id: 'atlas-hiking-1',
    title: 'Atlas Mountains Hiking',
    image: 'https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 890,
    duration: '1 day',
    category: 'Adventure'
  }
];