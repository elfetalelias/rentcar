import React from 'react';
import { useTranslation } from 'react-i18next';
import { Car as CarType } from '../types';
import { Users, Settings, Snowflake, MapPin } from 'lucide-react';

interface CarCardProps {
  car: CarType;
  onBookClick: (carId: string) => void;
}

export const CarCard: React.FC<CarCardProps> = ({ car, onBookClick }) => {
  const { t } = useTranslation();

  const minPrice = car.dailyPrice * car.minDays;

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative">
        <img
          src={car.image}
          alt={`${car.brand} ${car.model}`}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
            {t('available_now')}
          </span>
        </div>
        <div className="absolute top-4 right-4">
          <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
            {t('free_delivery')}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900">
              {car.brand} {car.model}
            </h3>
            <p className="text-gray-600 capitalize">{car.category}</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-orange-600">
              {car.dailyPrice} MAD
            </p>
            <p className="text-sm text-gray-500">{t('per_day')}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <Settings size={16} />
            <span>{t(car.transmission)}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users size={16} />
            <span>{car.seats} {t('seats')}</span>
          </div>
          {car.hasAC && (
            <div className="flex items-center gap-1">
              <Snowflake size={16} />
              <span>{t('air_conditioning')}</span>
            </div>
          )}
        </div>
        
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">{t('delivery_zones.center')}</p>
          <p className="text-sm text-gray-600 mb-2">{t('delivery_zones.mid')}</p>
          <p className="text-sm text-gray-600">{t('delivery_zones.far')}</p>
        </div>
        
        <div className="border-t pt-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-600">{t('from')} {car.minDays} {t('days')}:</span>
            <span className="text-lg font-semibold text-gray-900">{minPrice} MAD</span>
          </div>
          <button
            onClick={() => onBookClick(car.id)}
            className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg font-semibold hover:from-orange-600 hover:to-orange-700 transition-all duration-200 transform hover:scale-105"
          >
            {t('book_now')}
          </button>
        </div>
      </div>
    </div>
  );
};