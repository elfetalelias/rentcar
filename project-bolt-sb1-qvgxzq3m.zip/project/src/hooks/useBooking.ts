import { useState, useCallback } from 'react';
import { BookingDetails } from '../types';

export const useBooking = () => {
  const [bookingDetails, setBookingDetails] = useState<BookingDetails | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const calculatePricing = useCallback((
    dailyPrice: number,
    days: number,
    deliveryFee: number = 0
  ) => {
    const basePrice = dailyPrice * days;
    const vatRate = 0.20;
    const vatAmount = (basePrice + deliveryFee) * vatRate;
    const finalTotal = basePrice + deliveryFee + vatAmount;

    return {
      basePrice,
      deliveryFee,
      vatAmount,
      finalTotal
    };
  }, []);

  const createBooking = useCallback((
    carId: string,
    cityId: string,
    days: number,
    dailyPrice: number,
    deliveryFee: number = 0
  ) => {
    const pricing = calculatePricing(dailyPrice, days, deliveryFee);
    const startDate = new Date().toISOString();
    const endDate = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();

    const booking: BookingDetails = {
      carId,
      cityId,
      startDate,
      endDate,
      days,
      totalPrice: pricing.basePrice,
      deliveryFee: pricing.deliveryFee,
      vatAmount: pricing.vatAmount,
      finalTotal: pricing.finalTotal
    };

    setBookingDetails(booking);
    return booking;
  }, [calculatePricing]);

  const clearBooking = useCallback(() => {
    setBookingDetails(null);
  }, []);

  return {
    bookingDetails,
    isLoading,
    calculatePricing,
    createBooking,
    clearBooking
  };
};