import React from 'react';
import { useTranslation } from 'react-i18next';
import { CitySelector } from './CitySelector';

interface HeroSectionProps {
  selectedCity: string;
  onCityChange: (city: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ selectedCity, onCityChange }) => {
  const { t } = useTranslation();

  return (
    <section className="relative h-[70vh] bg-gradient-to-r from-orange-600 to-blue-700 flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg?auto=compress&cs=tinysrgb&w=1920)'
        }}
      />
      
      <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
          {t('hero_title')}
        </h1>
        <p className="text-xl md:text-2xl mb-8 opacity-90">
          {t('hero_subtitle')}
        </p>
        
        <div className="max-w-md mx-auto">
          <CitySelector 
            selectedCity={selectedCity} 
            onCityChange={onCityChange}
          />
        </div>
      </div>
    </section>
  );
};